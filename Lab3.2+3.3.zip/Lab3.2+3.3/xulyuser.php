<head>
<style>
    body {
        display: flex;
        justify-content: space-around;
        align-items: flex-start;
    } 
    .title-and-full-name-section {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }
</style>
</head>

<html>
<body>
<?php require_once 'ketnoi.php' ?>
<?php
if (isset($_POST['Register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $title = $_POST['title'];
    $fullname = $_POST['fullname'];
    $companyname = $_POST['companyname'];
    $password = $_POST['password'];
//Check password requirements
if(isUsernameDuplicate($username)||isEmailDuplicate($email)) {
    echo "<script>alert('Username or email already exists')</script>";
}else{
    if(!isValidPassword($password)){
        echo "<script>alert('Password not strong enough')</script>";
    }else{
        $result=$conn -> query("INSERT INTO user (username,email,title,fullname,companyname,password) VALUES('$username','$email','$title','$fullname','$companyname','$password')");
        if($result){   
            echo "<script>alert('Register successfully')</script>";
        }else{
            echo "<script>alert('Register failed')</script>";}
}
}
}

if (isset($_POST['login'])) {
    $loginUsername = $_POST['username'];
    $loginPassword = $_POST['password'];

    if(isValidLogin($loginUsername,$loginPassword)){
        echo"<script>alert('Login successful')</script>"; 
        }else{
        echo "<script>alert('Login failed')</script>";
        }
    //Create cookie when press Remember Me
        if(isset($_POST['remember_me']) && $_POST['remember_me'] == 'on'){
        setcookie('username', $loginUsername, time() + 3600 * 24 * 31); 
        setcookie('password', $loginPassword, time() + 3600 * 24 * 31);
    }
    //Display Cookies
    if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
        $savedUsername = $_COOKIE['username'];
        $savedPassword = $_COOKIE['password'];
    
        echo "<script>alert('Username: $savedUsername, Password: $savedPassword')</script>";
    }
    }
//Check login information 
function isValidLogin($loginUsername, $loginPassword){
    global $conn;
    $result = $conn->query("SELECT * FROM user WHERE username='$loginUsername'");
    if ($result->num_rows > 0){
        $row = $result->fetch_assoc();
        $storedPassword = $row['password'];
        if ($loginPassword === $storedPassword) {
            return true; 
        }
    }
}

//Check if username duplicates
function isUsernameDuplicate($username){
    global $conn;
    $result=$conn -> query("SELECT*FROM user WHERE username='$username'");
    return $result->num_rows > 0;
}//Check if email duplicates
function isEmailDuplicate($email){
    global $conn;
    $result=$conn -> query("SELECT*FROM user WHERE email='$email'");
    return $result->num_rows > 0;
}
//Check password function
function isValidPassword($password) {
    // Check if length >8
    if (strlen($password) < 8) {
        return false;
    }

    // Check uppercase
    if (!preg_match("/[A-Z]/", $password)) {
        return false;
    }

    // Check lowercase
    if (!preg_match("/[a-z]/", $password)) {
        return false;
    }

    // Check numbers
    if (!preg_match("/[0-9]/", $password)) {
        return false;
    }

    // Check special characters
    if (!preg_match("/[\W_]/", $password)) {
        return false;
    }
        return true;
}
?>

<div>
    <h2><strong>Login</strong></h2>
    <form method="post" action="xulyuser.php">
        <strong>Username</strong><br><input type="text" name="username" required><br>
        <br>
        <strong>Password</strong><br> <input type="password" name="password" required><br>
        <br>
        <input type="checkbox" name="remember_me"> <strong>Remember Me</strong><br>
        <br>
        <input type="submit" name="login" value="Login">
        <br>
    </form>
</div>

<div>
    <h2><strong>Signup for New Account?</strong></h2>
    <form method="post" action="xulyuser.php">
        <strong>Username</strong><br><input type="text" name="username" required><br>
        <br>
        <strong>User Email*</strong><br><input type="email" name="email" required><br>
        <br>
        <strong>Password</strong><br><input type="password" name="password" required><br>
        <br>
        <div class="title-and-full-name-section">
            <div class="title-and-full-name-section__title">
                <p><strong>Select Title</strong></p>
                <select name="title">
                    <?php
                    // Array of Titles
                    $titles = array("Mr", "Mrs", "Miss", "Ms", "Dr");

                    // Making options
                    foreach ($titles as $title) {
                        echo "<option value=\"$title\">$title</option>";
                    }
                    ?>        
                </select>
            </div>

            <div class="title-and-full-name-section__full-name">
                <p><strong>Full Name</strong></p>
                <input type="text" name="fullname" required>              
            </div>        
        </div> 
        <br>
        <strong>Company detail</strong><br>
        <br>
        Provide detail about your company</strong><br>
        <strong>Company name</strong><br><input type="text" name="companyname" required><br>
        <input type="checkbox" name="remember_me"> I am agree with registration<br>
        <input type="submit" name="Register" value="Register">
    </form>
</div>
</body>
</html>
