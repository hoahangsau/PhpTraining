<?php
 $conn = mysqli_connect('localhost','root','','Login');
 mysqli_set_charset($conn, "utf8");
?>